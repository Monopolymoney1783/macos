/*
 * module to include the modules
 */

#if defined(linux)
config_require(rmon-mib/data_access/etherstats_linux)
#endif
