/* err.h for openssl */

#ifndef yaSSL_err_h__
#define yaSSL_err_h__



#endif /* yaSSL_err_h__ */
