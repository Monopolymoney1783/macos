
kCommandStrokedAndFilledRects = 1000
kCommandAlphaRects = 1001
kCommandSimpleClip = 1002
kCommandDrawImageFile = 1003
kCommandDoUncachedDrawing = 1004
kCommandDoCGLayer = 1005
