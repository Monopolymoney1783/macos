import needsthis

def somefunc():
    print "Hello from py2app"

if __name__ == '__main__':
    somefunc()
