:mod:`mpl_toolkits.axes_grid.axes_size`
=======================================

.. automodule:: mpl_toolkits.axes_grid.axes_size
   :members: Fixed, Scaled, AxesX, AxesY, MaxWidth, MaxHeight, Fraction, Padded, from_any

