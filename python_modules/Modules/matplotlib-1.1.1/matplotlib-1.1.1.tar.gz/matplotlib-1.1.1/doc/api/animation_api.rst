*********
animation
*********


:mod:`matplotlib.animation`
===========================

.. automodule:: matplotlib.animation
   :members:
   :undoc-members:
   :show-inheritance:
