***********
collections
***********

.. inheritance-diagram:: matplotlib.collections
   :parts: 2

:mod:`matplotlib.collections`
=============================

.. automodule:: matplotlib.collections
   :members:
   :undoc-members:
   :show-inheritance:
