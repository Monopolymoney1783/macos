********
gridspec
********


:mod:`matplotlib.gridspec`
==========================

.. automodule:: matplotlib.gridspec
   :members:
   :undoc-members:
   :show-inheritance:
