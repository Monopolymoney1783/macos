/*
 * src/backend/port/dynloader/solaris.c
 *
 * Dummy file used for nothing at this point
 *
 * see solaris.h
 */
