/*
 * src/backend/port/dynloader/osf.c
 *
 * Dummy file used for nothing at this point
 *
 * see osf.h
 */
