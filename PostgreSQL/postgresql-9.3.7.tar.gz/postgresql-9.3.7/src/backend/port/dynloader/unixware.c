/*
 * src/backend/port/dynloader/unixware.c
 *
 * Dummy file used for nothing at this point
 *
 * see unixware.h
 */
