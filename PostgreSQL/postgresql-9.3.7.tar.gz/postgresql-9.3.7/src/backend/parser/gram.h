/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     IDENT = 258,
     FCONST = 259,
     SCONST = 260,
     BCONST = 261,
     XCONST = 262,
     Op = 263,
     ICONST = 264,
     PARAM = 265,
     TYPECAST = 266,
     DOT_DOT = 267,
     COLON_EQUALS = 268,
     ABORT_P = 269,
     ABSOLUTE_P = 270,
     ACCESS = 271,
     ACTION = 272,
     ADD_P = 273,
     ADMIN = 274,
     AFTER = 275,
     AGGREGATE = 276,
     ALL = 277,
     ALSO = 278,
     ALTER = 279,
     ALWAYS = 280,
     ANALYSE = 281,
     ANALYZE = 282,
     AND = 283,
     ANY = 284,
     ARRAY = 285,
     AS = 286,
     ASC = 287,
     ASSERTION = 288,
     ASSIGNMENT = 289,
     ASYMMETRIC = 290,
     AT = 291,
     ATTRIBUTE = 292,
     AUTHORIZATION = 293,
     BACKWARD = 294,
     BEFORE = 295,
     BEGIN_P = 296,
     BETWEEN = 297,
     BIGINT = 298,
     BINARY = 299,
     BIT = 300,
     BOOLEAN_P = 301,
     BOTH = 302,
     BY = 303,
     CACHE = 304,
     CALLED = 305,
     CASCADE = 306,
     CASCADED = 307,
     CASE = 308,
     CAST = 309,
     CATALOG_P = 310,
     CHAIN = 311,
     CHAR_P = 312,
     CHARACTER = 313,
     CHARACTERISTICS = 314,
     CHECK = 315,
     CHECKPOINT = 316,
     CLASS = 317,
     CLOSE = 318,
     CLUSTER = 319,
     COALESCE = 320,
     COLLATE = 321,
     COLLATION = 322,
     COLUMN = 323,
     COMMENT = 324,
     COMMENTS = 325,
     COMMIT = 326,
     COMMITTED = 327,
     CONCURRENTLY = 328,
     CONFIGURATION = 329,
     CONNECTION = 330,
     CONSTRAINT = 331,
     CONSTRAINTS = 332,
     CONTENT_P = 333,
     CONTINUE_P = 334,
     CONVERSION_P = 335,
     COPY = 336,
     COST = 337,
     CREATE = 338,
     CROSS = 339,
     CSV = 340,
     CURRENT_P = 341,
     CURRENT_CATALOG = 342,
     CURRENT_DATE = 343,
     CURRENT_ROLE = 344,
     CURRENT_SCHEMA = 345,
     CURRENT_TIME = 346,
     CURRENT_TIMESTAMP = 347,
     CURRENT_USER = 348,
     CURSOR = 349,
     CYCLE = 350,
     DATA_P = 351,
     DATABASE = 352,
     DAY_P = 353,
     DEALLOCATE = 354,
     DEC = 355,
     DECIMAL_P = 356,
     DECLARE = 357,
     DEFAULT = 358,
     DEFAULTS = 359,
     DEFERRABLE = 360,
     DEFERRED = 361,
     DEFINER = 362,
     DELETE_P = 363,
     DELIMITER = 364,
     DELIMITERS = 365,
     DESC = 366,
     DICTIONARY = 367,
     DISABLE_P = 368,
     DISCARD = 369,
     DISTINCT = 370,
     DO = 371,
     DOCUMENT_P = 372,
     DOMAIN_P = 373,
     DOUBLE_P = 374,
     DROP = 375,
     EACH = 376,
     ELSE = 377,
     ENABLE_P = 378,
     ENCODING = 379,
     ENCRYPTED = 380,
     END_P = 381,
     ENUM_P = 382,
     ESCAPE = 383,
     EVENT = 384,
     EXCEPT = 385,
     EXCLUDE = 386,
     EXCLUDING = 387,
     EXCLUSIVE = 388,
     EXECUTE = 389,
     EXISTS = 390,
     EXPLAIN = 391,
     EXTENSION = 392,
     EXTERNAL = 393,
     EXTRACT = 394,
     FALSE_P = 395,
     FAMILY = 396,
     FETCH = 397,
     FIRST_P = 398,
     FLOAT_P = 399,
     FOLLOWING = 400,
     FOR = 401,
     FORCE = 402,
     FOREIGN = 403,
     FORWARD = 404,
     FREEZE = 405,
     FROM = 406,
     FULL = 407,
     FUNCTION = 408,
     FUNCTIONS = 409,
     GLOBAL = 410,
     GRANT = 411,
     GRANTED = 412,
     GREATEST = 413,
     GROUP_P = 414,
     HANDLER = 415,
     HAVING = 416,
     HEADER_P = 417,
     HOLD = 418,
     HOUR_P = 419,
     IDENTITY_P = 420,
     IF_P = 421,
     ILIKE = 422,
     IMMEDIATE = 423,
     IMMUTABLE = 424,
     IMPLICIT_P = 425,
     IN_P = 426,
     INCLUDING = 427,
     INCREMENT = 428,
     INDEX = 429,
     INDEXES = 430,
     INHERIT = 431,
     INHERITS = 432,
     INITIALLY = 433,
     INLINE_P = 434,
     INNER_P = 435,
     INOUT = 436,
     INPUT_P = 437,
     INSENSITIVE = 438,
     INSERT = 439,
     INSTEAD = 440,
     INT_P = 441,
     INTEGER = 442,
     INTERSECT = 443,
     INTERVAL = 444,
     INTO = 445,
     INVOKER = 446,
     IS = 447,
     ISNULL = 448,
     ISOLATION = 449,
     JOIN = 450,
     KEY = 451,
     LABEL = 452,
     LANGUAGE = 453,
     LARGE_P = 454,
     LAST_P = 455,
     LATERAL_P = 456,
     LC_COLLATE_P = 457,
     LC_CTYPE_P = 458,
     LEADING = 459,
     LEAKPROOF = 460,
     LEAST = 461,
     LEFT = 462,
     LEVEL = 463,
     LIKE = 464,
     LIMIT = 465,
     LISTEN = 466,
     LOAD = 467,
     LOCAL = 468,
     LOCALTIME = 469,
     LOCALTIMESTAMP = 470,
     LOCATION = 471,
     LOCK_P = 472,
     MAPPING = 473,
     MATCH = 474,
     MATERIALIZED = 475,
     MAXVALUE = 476,
     MINUTE_P = 477,
     MINVALUE = 478,
     MODE = 479,
     MONTH_P = 480,
     MOVE = 481,
     NAME_P = 482,
     NAMES = 483,
     NATIONAL = 484,
     NATURAL = 485,
     NCHAR = 486,
     NEXT = 487,
     NO = 488,
     NONE = 489,
     NOT = 490,
     NOTHING = 491,
     NOTIFY = 492,
     NOTNULL = 493,
     NOWAIT = 494,
     NULL_P = 495,
     NULLIF = 496,
     NULLS_P = 497,
     NUMERIC = 498,
     OBJECT_P = 499,
     OF = 500,
     OFF = 501,
     OFFSET = 502,
     OIDS = 503,
     ON = 504,
     ONLY = 505,
     OPERATOR = 506,
     OPTION = 507,
     OPTIONS = 508,
     OR = 509,
     ORDER = 510,
     OUT_P = 511,
     OUTER_P = 512,
     OVER = 513,
     OVERLAPS = 514,
     OVERLAY = 515,
     OWNED = 516,
     OWNER = 517,
     PARSER = 518,
     PARTIAL = 519,
     PARTITION = 520,
     PASSING = 521,
     PASSWORD = 522,
     PLACING = 523,
     PLANS = 524,
     POSITION = 525,
     PRECEDING = 526,
     PRECISION = 527,
     PRESERVE = 528,
     PREPARE = 529,
     PREPARED = 530,
     PRIMARY = 531,
     PRIOR = 532,
     PRIVILEGES = 533,
     PROCEDURAL = 534,
     PROCEDURE = 535,
     PROGRAM = 536,
     QUOTE = 537,
     RANGE = 538,
     READ = 539,
     REAL = 540,
     REASSIGN = 541,
     RECHECK = 542,
     RECURSIVE = 543,
     REF = 544,
     REFERENCES = 545,
     REFRESH = 546,
     REINDEX = 547,
     RELATIVE_P = 548,
     RELEASE = 549,
     RENAME = 550,
     REPEATABLE = 551,
     REPLACE = 552,
     REPLICA = 553,
     RESET = 554,
     RESTART = 555,
     RESTRICT = 556,
     RETURNING = 557,
     RETURNS = 558,
     REVOKE = 559,
     RIGHT = 560,
     ROLE = 561,
     ROLLBACK = 562,
     ROW = 563,
     ROWS = 564,
     RULE = 565,
     SAVEPOINT = 566,
     SCHEMA = 567,
     SCROLL = 568,
     SEARCH = 569,
     SECOND_P = 570,
     SECURITY = 571,
     SELECT = 572,
     SEQUENCE = 573,
     SEQUENCES = 574,
     SERIALIZABLE = 575,
     SERVER = 576,
     SESSION = 577,
     SESSION_USER = 578,
     SET = 579,
     SETOF = 580,
     SHARE = 581,
     SHOW = 582,
     SIMILAR = 583,
     SIMPLE = 584,
     SMALLINT = 585,
     SNAPSHOT = 586,
     SOME = 587,
     STABLE = 588,
     STANDALONE_P = 589,
     START = 590,
     STATEMENT = 591,
     STATISTICS = 592,
     STDIN = 593,
     STDOUT = 594,
     STORAGE = 595,
     STRICT_P = 596,
     STRIP_P = 597,
     SUBSTRING = 598,
     SYMMETRIC = 599,
     SYSID = 600,
     SYSTEM_P = 601,
     TABLE = 602,
     TABLES = 603,
     TABLESPACE = 604,
     TEMP = 605,
     TEMPLATE = 606,
     TEMPORARY = 607,
     TEXT_P = 608,
     THEN = 609,
     TIME = 610,
     TIMESTAMP = 611,
     TO = 612,
     TRAILING = 613,
     TRANSACTION = 614,
     TREAT = 615,
     TRIGGER = 616,
     TRIM = 617,
     TRUE_P = 618,
     TRUNCATE = 619,
     TRUSTED = 620,
     TYPE_P = 621,
     TYPES_P = 622,
     UNBOUNDED = 623,
     UNCOMMITTED = 624,
     UNENCRYPTED = 625,
     UNION = 626,
     UNIQUE = 627,
     UNKNOWN = 628,
     UNLISTEN = 629,
     UNLOGGED = 630,
     UNTIL = 631,
     UPDATE = 632,
     USER = 633,
     USING = 634,
     VACUUM = 635,
     VALID = 636,
     VALIDATE = 637,
     VALIDATOR = 638,
     VALUE_P = 639,
     VALUES = 640,
     VARCHAR = 641,
     VARIADIC = 642,
     VARYING = 643,
     VERBOSE = 644,
     VERSION_P = 645,
     VIEW = 646,
     VOLATILE = 647,
     WHEN = 648,
     WHERE = 649,
     WHITESPACE_P = 650,
     WINDOW = 651,
     WITH = 652,
     WITHOUT = 653,
     WORK = 654,
     WRAPPER = 655,
     WRITE = 656,
     XML_P = 657,
     XMLATTRIBUTES = 658,
     XMLCONCAT = 659,
     XMLELEMENT = 660,
     XMLEXISTS = 661,
     XMLFOREST = 662,
     XMLPARSE = 663,
     XMLPI = 664,
     XMLROOT = 665,
     XMLSERIALIZE = 666,
     YEAR_P = 667,
     YES_P = 668,
     ZONE = 669,
     NULLS_FIRST = 670,
     NULLS_LAST = 671,
     WITH_TIME = 672,
     POSTFIXOP = 673,
     UMINUS = 674
   };
#endif
/* Tokens.  */
#define IDENT 258
#define FCONST 259
#define SCONST 260
#define BCONST 261
#define XCONST 262
#define Op 263
#define ICONST 264
#define PARAM 265
#define TYPECAST 266
#define DOT_DOT 267
#define COLON_EQUALS 268
#define ABORT_P 269
#define ABSOLUTE_P 270
#define ACCESS 271
#define ACTION 272
#define ADD_P 273
#define ADMIN 274
#define AFTER 275
#define AGGREGATE 276
#define ALL 277
#define ALSO 278
#define ALTER 279
#define ALWAYS 280
#define ANALYSE 281
#define ANALYZE 282
#define AND 283
#define ANY 284
#define ARRAY 285
#define AS 286
#define ASC 287
#define ASSERTION 288
#define ASSIGNMENT 289
#define ASYMMETRIC 290
#define AT 291
#define ATTRIBUTE 292
#define AUTHORIZATION 293
#define BACKWARD 294
#define BEFORE 295
#define BEGIN_P 296
#define BETWEEN 297
#define BIGINT 298
#define BINARY 299
#define BIT 300
#define BOOLEAN_P 301
#define BOTH 302
#define BY 303
#define CACHE 304
#define CALLED 305
#define CASCADE 306
#define CASCADED 307
#define CASE 308
#define CAST 309
#define CATALOG_P 310
#define CHAIN 311
#define CHAR_P 312
#define CHARACTER 313
#define CHARACTERISTICS 314
#define CHECK 315
#define CHECKPOINT 316
#define CLASS 317
#define CLOSE 318
#define CLUSTER 319
#define COALESCE 320
#define COLLATE 321
#define COLLATION 322
#define COLUMN 323
#define COMMENT 324
#define COMMENTS 325
#define COMMIT 326
#define COMMITTED 327
#define CONCURRENTLY 328
#define CONFIGURATION 329
#define CONNECTION 330
#define CONSTRAINT 331
#define CONSTRAINTS 332
#define CONTENT_P 333
#define CONTINUE_P 334
#define CONVERSION_P 335
#define COPY 336
#define COST 337
#define CREATE 338
#define CROSS 339
#define CSV 340
#define CURRENT_P 341
#define CURRENT_CATALOG 342
#define CURRENT_DATE 343
#define CURRENT_ROLE 344
#define CURRENT_SCHEMA 345
#define CURRENT_TIME 346
#define CURRENT_TIMESTAMP 347
#define CURRENT_USER 348
#define CURSOR 349
#define CYCLE 350
#define DATA_P 351
#define DATABASE 352
#define DAY_P 353
#define DEALLOCATE 354
#define DEC 355
#define DECIMAL_P 356
#define DECLARE 357
#define DEFAULT 358
#define DEFAULTS 359
#define DEFERRABLE 360
#define DEFERRED 361
#define DEFINER 362
#define DELETE_P 363
#define DELIMITER 364
#define DELIMITERS 365
#define DESC 366
#define DICTIONARY 367
#define DISABLE_P 368
#define DISCARD 369
#define DISTINCT 370
#define DO 371
#define DOCUMENT_P 372
#define DOMAIN_P 373
#define DOUBLE_P 374
#define DROP 375
#define EACH 376
#define ELSE 377
#define ENABLE_P 378
#define ENCODING 379
#define ENCRYPTED 380
#define END_P 381
#define ENUM_P 382
#define ESCAPE 383
#define EVENT 384
#define EXCEPT 385
#define EXCLUDE 386
#define EXCLUDING 387
#define EXCLUSIVE 388
#define EXECUTE 389
#define EXISTS 390
#define EXPLAIN 391
#define EXTENSION 392
#define EXTERNAL 393
#define EXTRACT 394
#define FALSE_P 395
#define FAMILY 396
#define FETCH 397
#define FIRST_P 398
#define FLOAT_P 399
#define FOLLOWING 400
#define FOR 401
#define FORCE 402
#define FOREIGN 403
#define FORWARD 404
#define FREEZE 405
#define FROM 406
#define FULL 407
#define FUNCTION 408
#define FUNCTIONS 409
#define GLOBAL 410
#define GRANT 411
#define GRANTED 412
#define GREATEST 413
#define GROUP_P 414
#define HANDLER 415
#define HAVING 416
#define HEADER_P 417
#define HOLD 418
#define HOUR_P 419
#define IDENTITY_P 420
#define IF_P 421
#define ILIKE 422
#define IMMEDIATE 423
#define IMMUTABLE 424
#define IMPLICIT_P 425
#define IN_P 426
#define INCLUDING 427
#define INCREMENT 428
#define INDEX 429
#define INDEXES 430
#define INHERIT 431
#define INHERITS 432
#define INITIALLY 433
#define INLINE_P 434
#define INNER_P 435
#define INOUT 436
#define INPUT_P 437
#define INSENSITIVE 438
#define INSERT 439
#define INSTEAD 440
#define INT_P 441
#define INTEGER 442
#define INTERSECT 443
#define INTERVAL 444
#define INTO 445
#define INVOKER 446
#define IS 447
#define ISNULL 448
#define ISOLATION 449
#define JOIN 450
#define KEY 451
#define LABEL 452
#define LANGUAGE 453
#define LARGE_P 454
#define LAST_P 455
#define LATERAL_P 456
#define LC_COLLATE_P 457
#define LC_CTYPE_P 458
#define LEADING 459
#define LEAKPROOF 460
#define LEAST 461
#define LEFT 462
#define LEVEL 463
#define LIKE 464
#define LIMIT 465
#define LISTEN 466
#define LOAD 467
#define LOCAL 468
#define LOCALTIME 469
#define LOCALTIMESTAMP 470
#define LOCATION 471
#define LOCK_P 472
#define MAPPING 473
#define MATCH 474
#define MATERIALIZED 475
#define MAXVALUE 476
#define MINUTE_P 477
#define MINVALUE 478
#define MODE 479
#define MONTH_P 480
#define MOVE 481
#define NAME_P 482
#define NAMES 483
#define NATIONAL 484
#define NATURAL 485
#define NCHAR 486
#define NEXT 487
#define NO 488
#define NONE 489
#define NOT 490
#define NOTHING 491
#define NOTIFY 492
#define NOTNULL 493
#define NOWAIT 494
#define NULL_P 495
#define NULLIF 496
#define NULLS_P 497
#define NUMERIC 498
#define OBJECT_P 499
#define OF 500
#define OFF 501
#define OFFSET 502
#define OIDS 503
#define ON 504
#define ONLY 505
#define OPERATOR 506
#define OPTION 507
#define OPTIONS 508
#define OR 509
#define ORDER 510
#define OUT_P 511
#define OUTER_P 512
#define OVER 513
#define OVERLAPS 514
#define OVERLAY 515
#define OWNED 516
#define OWNER 517
#define PARSER 518
#define PARTIAL 519
#define PARTITION 520
#define PASSING 521
#define PASSWORD 522
#define PLACING 523
#define PLANS 524
#define POSITION 525
#define PRECEDING 526
#define PRECISION 527
#define PRESERVE 528
#define PREPARE 529
#define PREPARED 530
#define PRIMARY 531
#define PRIOR 532
#define PRIVILEGES 533
#define PROCEDURAL 534
#define PROCEDURE 535
#define PROGRAM 536
#define QUOTE 537
#define RANGE 538
#define READ 539
#define REAL 540
#define REASSIGN 541
#define RECHECK 542
#define RECURSIVE 543
#define REF 544
#define REFERENCES 545
#define REFRESH 546
#define REINDEX 547
#define RELATIVE_P 548
#define RELEASE 549
#define RENAME 550
#define REPEATABLE 551
#define REPLACE 552
#define REPLICA 553
#define RESET 554
#define RESTART 555
#define RESTRICT 556
#define RETURNING 557
#define RETURNS 558
#define REVOKE 559
#define RIGHT 560
#define ROLE 561
#define ROLLBACK 562
#define ROW 563
#define ROWS 564
#define RULE 565
#define SAVEPOINT 566
#define SCHEMA 567
#define SCROLL 568
#define SEARCH 569
#define SECOND_P 570
#define SECURITY 571
#define SELECT 572
#define SEQUENCE 573
#define SEQUENCES 574
#define SERIALIZABLE 575
#define SERVER 576
#define SESSION 577
#define SESSION_USER 578
#define SET 579
#define SETOF 580
#define SHARE 581
#define SHOW 582
#define SIMILAR 583
#define SIMPLE 584
#define SMALLINT 585
#define SNAPSHOT 586
#define SOME 587
#define STABLE 588
#define STANDALONE_P 589
#define START 590
#define STATEMENT 591
#define STATISTICS 592
#define STDIN 593
#define STDOUT 594
#define STORAGE 595
#define STRICT_P 596
#define STRIP_P 597
#define SUBSTRING 598
#define SYMMETRIC 599
#define SYSID 600
#define SYSTEM_P 601
#define TABLE 602
#define TABLES 603
#define TABLESPACE 604
#define TEMP 605
#define TEMPLATE 606
#define TEMPORARY 607
#define TEXT_P 608
#define THEN 609
#define TIME 610
#define TIMESTAMP 611
#define TO 612
#define TRAILING 613
#define TRANSACTION 614
#define TREAT 615
#define TRIGGER 616
#define TRIM 617
#define TRUE_P 618
#define TRUNCATE 619
#define TRUSTED 620
#define TYPE_P 621
#define TYPES_P 622
#define UNBOUNDED 623
#define UNCOMMITTED 624
#define UNENCRYPTED 625
#define UNION 626
#define UNIQUE 627
#define UNKNOWN 628
#define UNLISTEN 629
#define UNLOGGED 630
#define UNTIL 631
#define UPDATE 632
#define USER 633
#define USING 634
#define VACUUM 635
#define VALID 636
#define VALIDATE 637
#define VALIDATOR 638
#define VALUE_P 639
#define VALUES 640
#define VARCHAR 641
#define VARIADIC 642
#define VARYING 643
#define VERBOSE 644
#define VERSION_P 645
#define VIEW 646
#define VOLATILE 647
#define WHEN 648
#define WHERE 649
#define WHITESPACE_P 650
#define WINDOW 651
#define WITH 652
#define WITHOUT 653
#define WORK 654
#define WRAPPER 655
#define WRITE 656
#define XML_P 657
#define XMLATTRIBUTES 658
#define XMLCONCAT 659
#define XMLELEMENT 660
#define XMLEXISTS 661
#define XMLFOREST 662
#define XMLPARSE 663
#define XMLPI 664
#define XMLROOT 665
#define XMLSERIALIZE 666
#define YEAR_P 667
#define YES_P 668
#define ZONE 669
#define NULLS_FIRST 670
#define NULLS_LAST 671
#define WITH_TIME 672
#define POSTFIXOP 673
#define UMINUS 674




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 176 "gram.y"
{
	core_YYSTYPE		core_yystype;
	/* these fields must match core_YYSTYPE: */
	int					ival;
	char				*str;
	const char			*keyword;

	char				chr;
	bool				boolean;
	JoinType			jtype;
	DropBehavior		dbehavior;
	OnCommitAction		oncommit;
	List				*list;
	Node				*node;
	Value				*value;
	ObjectType			objtype;
	TypeName			*typnam;
	FunctionParameter   *fun_param;
	FunctionParameterMode fun_param_mode;
	FuncWithArgs		*funwithargs;
	DefElem				*defelt;
	SortBy				*sortby;
	WindowDef			*windef;
	JoinExpr			*jexpr;
	IndexElem			*ielem;
	Alias				*alias;
	RangeVar			*range;
	IntoClause			*into;
	WithClause			*with;
	A_Indices			*aind;
	ResTarget			*target;
	struct PrivTarget	*privtarget;
	AccessPriv			*accesspriv;
	InsertStmt			*istmt;
	VariableSetStmt		*vsetstmt;
}
/* Line 1529 of yacc.c.  */
#line 924 "gram.tab.h"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} YYLTYPE;
# define yyltype YYLTYPE /* obsolescent; will be withdrawn */
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif


