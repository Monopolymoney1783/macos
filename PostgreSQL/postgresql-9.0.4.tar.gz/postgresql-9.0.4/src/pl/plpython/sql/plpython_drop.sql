--
-- For paranoia's sake, don't leave an untrusted language sitting around
--
SET client_min_messages = WARNING;

DROP PROCEDURAL LANGUAGE plpythonu CASCADE;
